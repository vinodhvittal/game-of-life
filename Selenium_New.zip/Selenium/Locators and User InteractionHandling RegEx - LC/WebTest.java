package sample;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class WebTest {
	
	WebDriver driver;
	
		@BeforeTest
		public void Launch()
		{
			System.setProperty("webdriver.chrome.driver", "C:\\Users\\572327\\Documents\\Chrome\\chromedriver.exe");
			driver =new ChromeDriver();
			driver.get("http://apps.qa2qe.cognizant.e-box.co.in/shippingDetails/");
			driver.manage().window().maximize();
		}
		@Test
		public void Validation() throws InterruptedException
		{
			Thread.sleep(5000);
			//WebElement element=driver.findElement(By.xpath("//h1/center"));
			String HeaderText = driver.findElement(By.xpath("//h2")).getText();
			if(HeaderText.trim().equals("Shipping Details")){
				List row=driver.findElements(By.xpath("//*[@id='shippingTable']/table/tbody//tr/td[1]/a[contains(text(),'6543217')]"));
				if(row.size()>0){
					System.out.println("Shippement ID 6543217 is present");
					driver.findElement(By.xpath("//*[@id='shippingTable']/table/tbody//tr/td[1]/a[contains(text(),'6543217')]")).click();
				}
				String tablecontent="//*[@id='result']/table/tbody//tr//td[contains(text(),'Maya')]";
				String shipmentDate="//*[@id='result']/table/tbody//tr//td[contains(text(),'Shipping Date : 03/12/2017')]";
				String accountno="//*[@id='result']/table/tbody//tr//td[contains(text(),'Account No : 93746537')]";
				List Content=driver.findElements(By.xpath(tablecontent));
				List ShipDate=driver.findElements(By.xpath(shipmentDate));
				List accno=driver.findElements(By.xpath(accountno));
				if(Content.size()>0){
					System.out.println("Maya is present in the table");
				}else{
					System.out.println("Maya is not present in the table");
				}
				if(ShipDate.size()>0){
					System.out.println("'Shipping Date : 03/12/2017' is present in the table");
				}else{
					System.out.println("'Shipping Date : 03/12/2017' is not present in the table");
				}
				if(accno.size()>0){
					System.out.println("'Account No : 93746537' is present in the table");
				}else{
					System.out.println("'Account No : 93746537' is not present in the table");
				}
			}else{
				System.out.println("Shipping details page is not present");
			}
			//System.out.println("Test");
			
		}
		@AfterTest
		public void Close(){
			driver.close();
		}

	
	
/*
	public static void main(String[] args) {
		
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\572327\\Documents\\Chrome\\chromedriver.exe");
		WebDriver driver =new ChromeDriver();
		//System.setProperty("webdriver.ie.driver", "C:\\Users\\572327\\Documents\\Chrome\\IEDriverServer.exe");
		//WebDriver driver =new InternetExplorerDriver();
		
		driver.get("http://apps.qa2qe.cognizant.e-box.co.in/WelcomeMessage/");
		driver.manage().window().maximize();
		Thread.sleep(5000);
			//WebElement element=driver.findElement(By.xpath("//h1/center"));
			String helloWorldTxt = driver.findElement(By.xpath("/html/body/h1/center")).getText();
			if(helloWorldTxt.trim().equals("WELCOME TO DATAX SHIPPING COMPANY")){
				System.out.println("Passed");
			}else{
				System.out.println("Failed");
			}
		

	}
	*/

}
