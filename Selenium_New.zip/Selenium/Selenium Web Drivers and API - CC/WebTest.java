package sample;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class WebTest {
	
		WebDriver driver;
	
		@BeforeTest
		public void Launch()
		{
			System.setProperty("webdriver.chrome.driver", "C:\\Users\\572327\\Documents\\Chrome\\chromedriver.exe");
			driver =new ChromeDriver();
			driver.get("http://apps.qa2qe.cognizant.e-box.co.in/ShippingDetails/");
			driver.manage().window().maximize();
		}
		@Test
		public void Validation() throws InterruptedException
		{
			Thread.sleep(5000);
			//WebElement element=driver.findElement(By.xpath("//h1/center"));
			String HeaderText = driver.findElement(By.xpath("/html/body/div[2]/h2")).getText();
			if(HeaderText.trim().equals("Shipping Details")){
				
				List Source=driver.findElements(By.xpath("//*[@id='source']"));
				List Dest=driver.findElements(By.xpath("//*[@id='destination']"));
				List Weight=driver.findElements(By.xpath("//*[@id='weight']"));
				List Cost=driver.findElements(By.xpath("//*[@id='cost']"));
				List Date=driver.findElements(By.xpath("//*[@id='date']"));
				List Delivery=driver.findElements(By.xpath("//*[@id='delivery']"));
				List Calculate=driver.findElements(By.xpath("//*[@id='calculate']"));
				List Result=driver.findElements(By.xpath("//*[@id='result']"));
				if(Source.size()>0){
					System.out.println("Source id is present in the page");
				}else{
					System.out.println("Source id is not present in the page");
				}
				if(Dest.size()>0){
					System.out.println("Destination id is present in the page");
				}else{
					System.out.println("Destination id is not present in the page");
				}
				if(Weight.size()>0){
					System.out.println("Weight id is present in the page");
				}else{
					System.out.println("Weight id is not present in the page");
				}
				if(Cost.size()>0){
					System.out.println("Cost id is present in the page");
				}else{
					System.out.println("Cost id is not present in the page");
				}
				if(Date.size()>0){
					System.out.println("Date id is present in the page");
				}else{
					System.out.println("Date id is not present in the page");
				}
				if(Delivery.size()>0){
					System.out.println("Delivery id is present in the page");
				}else{
					System.out.println("Delivery id is not present in the page");
				}
				if(Calculate.size()>0){
					System.out.println("Calculate id is present in the page");
				}else{
					System.out.println("Calculate id is not present in the page");
				}
				if(Result.size()>0){
					System.out.println("Result id is present in the page");
				}else{
					System.out.println("Result id is not present in the page");
				}
				
				

			}else{
				System.out.println("Shipping Details page is not displayed");
			}
			
			//System.out.println("Test");
			
		}
		@AfterTest
		public void Close(){
			driver.close();
		}

	
	
/*
	public static void main(String[] args) {
		
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\572327\\Documents\\Chrome\\chromedriver.exe");
		WebDriver driver =new ChromeDriver();
		//System.setProperty("webdriver.ie.driver", "C:\\Users\\572327\\Documents\\Chrome\\IEDriverServer.exe");
		//WebDriver driver =new InternetExplorerDriver();
		
		driver.get("http://apps.qa2qe.cognizant.e-box.co.in/WelcomeMessage/");
		driver.manage().window().maximize();
		Thread.sleep(5000);
			//WebElement element=driver.findElement(By.xpath("//h1/center"));
			String helloWorldTxt = driver.findElement(By.xpath("/html/body/h1/center")).getText();
			if(helloWorldTxt.trim().equals("WELCOME TO DATAX SHIPPING COMPANY")){
				System.out.println("Passed");
			}else{
				System.out.println("Failed");
			}
		

	}
	*/

}
