package sample;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class WebTest {
	
	WebDriver driver;
	
	@BeforeTest
		public void Launch()
		{
			System.setProperty("webdriver.chrome.driver", "C:\\Users\\572327\\Documents\\Chrome\\chromedriver.exe");
			driver =new ChromeDriver();
			driver.get("http://apps.qa2qe.cognizant.e-box.co.in/WelcomeMessage/");
			driver.manage().window().maximize();
		}
		@Test
		public void Validation() throws InterruptedException
		{
			Thread.sleep(5000);
			//WebElement element=driver.findElement(By.xpath("//h1/center"));
			String helloWorldTxt = driver.findElement(By.xpath("/html/body/h1/center")).getText();
			if(helloWorldTxt.trim().equals("WELCOME TO DATAX SHIPPING COMPANY")){
				System.out.println("Passed");
			}else{
				System.out.println("Failed");
			}
			//System.out.println("Test");
			
		}
		@AfterTest
		public void Close(){
			driver.close();
		}

	
	
/*
	public static void main(String[] args) {
		
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\572327\\Documents\\Chrome\\chromedriver.exe");
		WebDriver driver =new ChromeDriver();
		//System.setProperty("webdriver.ie.driver", "C:\\Users\\572327\\Documents\\Chrome\\IEDriverServer.exe");
		//WebDriver driver =new InternetExplorerDriver();
		
		driver.get("http://apps.qa2qe.cognizant.e-box.co.in/WelcomeMessage/");
		driver.manage().window().maximize();
		Thread.sleep(5000);
			//WebElement element=driver.findElement(By.xpath("//h1/center"));
			String helloWorldTxt = driver.findElement(By.xpath("/html/body/h1/center")).getText();
			if(helloWorldTxt.trim().equals("WELCOME TO DATAX SHIPPING COMPANY")){
				System.out.println("Passed");
			}else{
				System.out.println("Failed");
			}
		

	}
	*/

}
