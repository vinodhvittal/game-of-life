package com.cucumber.stepDefinition;

import static org.testng.Assert.assertEquals;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.DataTable;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDefinition {
	public WebDriver driver;

	List<List<String>> data ;
	String actual =null;
	int i,j=0;
	String nw=null;
//	List<String> expected;
 
	
	@Given("^user launch the the index URL$")
	public void user_launch_the_the_index_URL() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "D:\\chromedriver.exe");
		driver = new ChromeDriver();
	    driver.get("http://apps.qa2qe.cognizant.e-box.co.in/CucumberHostelFeeCalc/index.html");
	    driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
	     
	}
	  

	@When("^user enter name  as \"([^\"]*)\" type as \"([^\"]*)\"  number as  \"([^\"]*)\" and click on getfee$")
	public void user_enter_name_as_type_as_number_as_and_click_on_getfee(String arg1, String arg2, String arg3)  {
		driver.findElement(By.xpath("//*[@id='name']")).sendKeys(arg1);
		 driver.findElement(By.xpath("/html/body/center/form/table/tbody/tr[2]/td[2]/input["+arg2+"]")).click();
		 driver.findElement(By.id("getFee")).click();
	    
	}

	@Then("^collegefee hostelfee addiionalfee totalfee are displayed$")
	public void collegefee_hostelfee_addiionalfee_totalfee_are_displayed(DataTable arg1) throws InterruptedException  {
		 int count = arg1.raw().size();
		  data = arg1.raw();
		  
		  for(i=1, j=2; i<count;i++ ) {
		  String expectedcollegefee = data.get(i).get(0);
		  String expectedhostelfee = data.get(i).get(1);
			  String expectedadditionalfee = data.get(i).get(2);
			  String expectedtotalfee = data.get(i).get(3);
			  String actualcfee = driver.findElement(By.xpath("//*[@id='feeTable']/tbody/tr[1]/td[2]")).getText();
			  String actualhfee = driver.findElement(By.xpath("//*[@id='feeTable']/tbody/tr[2]/td[2]")).getText();
			  String actualadfee = driver.findElement(By.xpath("//*[@id='feeTable']/tbody/tr[3]/td[2]")).getText();
			  String acttota = driver.findElement(By.xpath("//*[@id='feeTable']/tbody/tr[4]/td[2]")).getText();
			  String expected = "College Fee "+ expectedcollegefee+ " " + "Hostel Fee " + expectedhostelfee + " "  + "Additional Fee" + expectedadditionalfee + " " + "Total Fee "+ expectedtotalfee ;
			   actual = "College Fee "+ actualcfee+ " " + "Hostel Fee " + actualhfee + " "  + "Additional Fee" + actualadfee + " " + "Total Fee "+ acttota ;
			  Thread.sleep(1000);
			  System.out.println("actual" + actual);
			  System.out.println("expected" +expected);
			  if(actual.equals(expected))
			  {
				  assertEquals(actual, expected);
				  break;
			  }
			 
		  }
		  }
 
	 
	}

	
 
 