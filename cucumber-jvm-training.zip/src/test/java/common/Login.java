package common;

public class Login {

	public static void loginToApplication() {

	}

}
