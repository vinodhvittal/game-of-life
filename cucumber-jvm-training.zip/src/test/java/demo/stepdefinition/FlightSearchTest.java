package demo.stepdefinition;

import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import common.Login;
import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.*;
import demo.page.*;

import static org.junit.Assert.*;

public class FlightSearchTest {

	static WebDriver driver;
	private Scenario scenario;
	private static HomePage homePage;
	private FlightSearchPage flightSearchPage;
	private FlightSelectPage flightSelectPage;
	private FlightRegisterPage flightRegisterPage;

	@Before
	public void setUp(Scenario scenario) {
		this.scenario = scenario;		
	}

	@Given("^I want to be able to search for Departure and Arrival flights$")
	public void i_want_to_be_able_to_search_for_Departure_and_Arrival_flights() {
		// Write code here that turns the phrase above into concrete actions
		String currentDir = System.getProperty("user.dir");
		String driverPath = currentDir + "\\chromedriver.exe";
		System.setProperty("webdriver.chrome.driver", driverPath);
		driver = new ChromeDriver();		
	}

	@When("^I navigate to the \"([^\"]*)\"$")
	public void i_navigate_to_the(String arg1) {
		// Write code here that turns the phrase above into concrete actions
		driver.get(arg1);
		driver.manage().window().maximize();
		
		Login.loginToApplication();
	}

	@Then("^I should see home page$")
	public void i_should_see_home_page() {
		// Write code here that turns the phrase above into concrete actions
		homePage = new HomePage(driver);
		assertTrue("Home page should be loaded", homePage.LoginButton.isDisplayed());		
		scenario.embed(((TakesScreenshot) driver).getScreenshotAs(OutputType.BYTES), "image/png");
	}

	@Then("^I click on Register Link$")
	public void i_click_on_Register_Link() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		homePage.RegisterLink.click();
	}

	@Then("^I enter first name \"([^\"]*)\"$")
	public void i_enter_first_name(String arg1) throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		flightRegisterPage = new FlightRegisterPage(driver);
		flightRegisterPage.FlightRegisterFirstName.sendKeys(arg1);
	}

	@Then("^I enter last name \"([^\"]*)\"$")
	public void i_enter_last_name(String arg1) throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		flightRegisterPage.FlightRegisterLastName.sendKeys(arg1);
	}

	@Then("^I enter phone \"([^\"]*)\"$")
	public void i_enter_phone(String arg1) throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		flightRegisterPage.FlightRegisterPhone.sendKeys(arg1);
	}

	@Then("^I enter email \"([^\"]*)\"$")
	public void i_enter_email(String arg1) throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		flightRegisterPage.FlightRegisterEmail.sendKeys(arg1);
	}

	@Then("^I enter address \"([^\"]*)\"$")
	public void i_enter_address(String arg1) throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		flightRegisterPage.FlightRegisterAddress1.sendKeys(arg1);
	}

	@Then("^I enter address line \"([^\"]*)\"$")
	public void i_enter_address_line(String arg1) throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		flightRegisterPage.FlightRegisterAddress2.sendKeys(arg1);
	}

	@Then("^I enter city \"([^\"]*)\"$")
	public void i_enter_city(String arg1) throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		flightRegisterPage.FlightRegisterCity.sendKeys(arg1);
	}

	@Then("^I enter state \"([^\"]*)\"$")
	public void i_enter_state(String arg1) throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		flightRegisterPage.FlightRegisterState.sendKeys(arg1);
	}

	@Then("^I enter postal code \"([^\"]*)\"$")
	public void i_enter_postal_code(String arg1) throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		flightRegisterPage.FlightRegisterPostalCode.sendKeys(arg1);
	}

	@Then("^I enter username \"([^\"]*)\"$")
	public void i_enter_username(String arg1) throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		flightRegisterPage.FlightRegisterUserName.sendKeys(arg1);
	}

	@Then("^I enter password \"([^\"]*)\"$")
	public void i_enter_password(String arg1) throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		flightRegisterPage.FlightRegisterPassword.sendKeys(arg1);
	}

	@Then("^I enter confirm password \"([^\"]*)\"$")
	public void i_enter_confirm_password(String arg1) throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		flightRegisterPage.FlightRegisterConfirmPassword.sendKeys(arg1);
	}

	@Then("^I click on submit$")
	public void i_click_on_submit() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		flightRegisterPage.FlightRegisterSubmit.click();
	}

	@Then("^I should see Thank you for registering message$")
	public void i_should_see_Thank_you_for_registering_message() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		assertTrue("User is successfully registered",
				flightRegisterPage.FlightRegisterMessage.getText().contains("Thank you for registering"));
		scenario.embed(((TakesScreenshot) driver).getScreenshotAs(OutputType.BYTES), "image/png");
	}

	@Then("^I click on Flights link$")
	public void i_click_on_Flights_link() {
		// Write code here that turns the phrase above into concrete actions
		homePage.FlightsLink.click();
	}

	@Then("^I click on Continue button$")
	public void i_click_on_Continue_button() {
		// Write code here that turns the phrase above into concrete actions
		flightSearchPage = new FlightSearchPage(driver);
		flightSearchPage.FlightSearchContinue.click();
	}

	@Then("^I should see Select Flight page$")
	public void i_should_see_Select_Flight_page() {
		// Write code here that turns the phrase above into concrete actions
		flightSelectPage = new FlightSelectPage(driver);
		assertTrue("Flight Selection Page should be displayed", flightSelectPage.DepartRadioButton.isDisplayed());
		scenario.embed(((TakesScreenshot) driver).getScreenshotAs(OutputType.BYTES), "image/png");
	}

	@After
	public void tearDown(Scenario scenario) {		
		if (scenario.isFailed()) {
			scenario.embed(((TakesScreenshot) driver).getScreenshotAs(OutputType.BYTES), "image/png");
		}
		driver.quit();
	}

	// todo to update zephyr test result

}
