package demo.runner;

import org.junit.runner.RunWith;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;
import cucumber.api.testng.CucumberFeatureWrapper;
import cucumber.api.testng.PickleEventWrapper;
import cucumber.api.testng.TestNGCucumberRunner;
import runner.AbstractTestNGCucumberTests;

@CucumberOptions(monochrome = true, features = { "src/test/java/demo/feature/FlightSearchfeature.Feature" }, glue = { "demo/stepdefinition" })
public class TestNgRunner extends AbstractTestNGCucumberTests {
	
	@BeforeTest
	@Parameters({"browser"})
	public void before(String browser){
		System.out.println(browser);
	}
}
