package demo.runner;

import java.io.File;

import org.junit.*;
import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;
import demo.listener.ExtentCucumberListener;

@RunWith(Cucumber.class)
@CucumberOptions(monochrome = true, features = { "src/test/java/demo/feature/FlightSearchfeature.Feature" }, glue = { "demo/stepdefinition" })
public class FlightRunner {
	@BeforeClass
	public static void setup() {
		ExtentCucumberListener.initiateExtentCucumberFormatter();
		ExtentCucumberListener.loadConfig(new File("reportConfig.xml"));
	}

	@AfterClass
	public static void tearDown() {
		// todo code to update Realtime dashboard
	}
}
