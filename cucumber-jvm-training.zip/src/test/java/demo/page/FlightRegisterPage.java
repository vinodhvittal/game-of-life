package demo.page;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class FlightRegisterPage {
	
	public WebDriver driver;

	@FindBy(name = "firstName1")
	public WebElement FlightRegisterFirstName;
	
	@FindBy(how = How.NAME, using = "lastName")
	public WebElement FlightRegisterLastName;
	
	@FindBy(how = How.NAME, using = "phone")
	public WebElement FlightRegisterPhone;
	
	@FindBy(id = "userName")
	public WebElement FlightRegisterEmail;
	
	@FindBy(how = How.NAME, using = "address1")
	public WebElement FlightRegisterAddress1;
	
	@FindBy(how = How.NAME, using = "address2")
	public WebElement FlightRegisterAddress2;
	
	@FindBy(how = How.NAME, using = "city")
	public WebElement FlightRegisterCity;
	
	@FindBy(how = How.NAME, using = "state")
	public WebElement FlightRegisterState;
	

	@FindBy(how = How.NAME, using = "postalCode")
	public WebElement FlightRegisterPostalCode;
	
	@FindBy(how = How.NAME, using = "email")
	public WebElement FlightRegisterUserName;
	
	@FindBy(how = How.NAME, using = "password")
	public WebElement FlightRegisterPassword;
	
	@FindBy(how = How.NAME, using = "confirmPassword")
	public WebElement FlightRegisterConfirmPassword;
	
	@FindBy(how = How.NAME, using = "register")
	public WebElement FlightRegisterSubmit;
	
	@FindBy(xpath = "/html/body/div/table/tbody/tr/td[2]/table/tbody/tr[4]/td/table/tbody/tr/td[2]/table/tbody/tr[3]/td/p[2]/font")
	public WebElement FlightRegisterMessage;
	
	public FlightRegisterPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

}
