package com.selenium.setup;

import java.io.File;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxBinary;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Parameters;


// Please do not change following code

public class DriverSetup {
	private WebDriver driver;
	public static String baseUrl = "http://apps.qa2qe.cognizant.e-box.co.in/Agent_Registration/";
	
	public WebDriver getDriver() {
		WebDriver driver = new FirefoxDriver();
		driver.navigate().to(DriverSetup.baseUrl);
		return driver;
	}

	
}
