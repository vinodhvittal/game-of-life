package com.selenium.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

//To check if you have followed the right naming convention for the methods as mentioned in the case study.

public class AgentForm {
// fill the code
	public WebDriver driver;
	public AgentForm (WebDriver driver)
	{
		this.driver = driver;
		PageFactory.initElements(this.driver, this);
	}
	
	@FindBy (how=How.NAME,name="firstname")
	WebElement firstName;
	
	@FindBy (how=How.NAME,name="lastname")
	WebElement lastName;
	
	@FindBy (how=How.NAME,name="username")
	WebElement userName;
	
	@FindBy (how=How.NAME,name="password")
	WebElement password;
	
	@FindBy (how=How.NAME,name="phonenumber")
	WebElement phoneNumber;
	
	@FindBy (how=How.NAME,name="email")
	WebElement email;
	
	@FindBy (how=How.ID,id="submit")
	WebElement submit;
	
	@FindBy (how=How.ID,id="message")
	WebElement message;

//Entering first name
public void setFirstName(String fnameTxt)
{
	firstName.sendKeys(fnameTxt);
}
//Entering last name
public void setLastName(String lnameTxt)
{
	lastName.sendKeys(lnameTxt);
}
//Entering user name
public void setUserName(String unameTxt)
{
	userName.sendKeys(unameTxt);
}
//Entering password
public void setPassword(String passwordTxt)
{
	password.sendKeys(passwordTxt);
}
//Entering phone number
public void setPhoneNumber(String phoneNumberTxt)
{
	phoneNumber.sendKeys(phoneNumberTxt);
}
//Entering first name
public void setEmail(String emailTxt)
{
	email.sendKeys(emailTxt);
}

//Storing the Error message
public String getErrorMessage()   
{
	String txt = message.getText();
	return txt;
			
}

//For Submitting the details
public void clickSubmit()
{
	submit.click();
}
//To Wait
public void tosleep(int i)

{
	try {
		Thread.sleep(i);
	} catch (InterruptedException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	}

}

