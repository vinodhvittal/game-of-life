package com.selenium.pages;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

//To check if you have followed the right naming convention for the methods as mentioned in the case study.

public class DisplayAgent {
	// fill the code 
	public WebDriver driver;
	public DisplayAgent (WebDriver driver)
	{
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	@FindBy (how=How.XPATH,xpath="//tbody/tr[1]/td[2]")
	WebElement nameTxt;

	@FindBy (how=How.XPATH,xpath="//tbody/tr[2]/td[2]")
	WebElement userNameTxt;

	@FindBy (how=How.XPATH,xpath="//tbody/tr[3]/td[2]")
	WebElement phoneNumberTxt;

	@FindBy (how=How.XPATH,xpath="//tbody/tr[4]/td[2]")
	WebElement emailTxt;

	@FindBy (how=How.XPATH,xpath="//body/h2")
	WebElement titleTxt;

	public String getTitle()
	{
		String txt = titleTxt.getText();
		
		return txt;
	}
	public String getName()
	{
		String txt = nameTxt.getText();
		
		return txt;
	}
	public String getUserName()
	{
		String txt = userNameTxt.getText();
		
		return txt;
	}
	public String getEmail()
	{
		String txt = emailTxt.getText();
		
		return txt;
	}
	public String getNumber()
	{
		String txt = phoneNumberTxt.getText();
		return txt;
	}

	
}
