//572849

package com.selenium.tests;


import org.testng.annotations.Test;
import org.testng.annotations.BeforeMethod;
import java.io.File;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.selenium.pages.AgentForm;
import com.selenium.pages.DisplayAgent;
import com.selenium.setup.DriverSetup;
import com.selenium.setup.ExcelUtils;

public class TestDisplayPage extends DriverSetup{
	AgentForm agentForm;
	WebDriver driver;
	DisplayAgent welcomepage;
	public static String titletxt;
	public static String nametxt;
	public static String unametxt;
	public static String phonenumbertxt;
	public static String emailtxt;




	@BeforeClass
	public void setUp() {
		driver = getDriver();
	}

	@Test
	public void testForValidAgent() throws Exception {
		ExcelUtils.setExcelFile();
		welcomepage = new DisplayAgent(driver);
		agentForm = new AgentForm(driver);
		
		//Getting the values from the excel 
		String firstName = ExcelUtils.getCellData(3, 1);
		
		String lastName = ExcelUtils.getCellData(3, 2);
		
		String username = ExcelUtils.getCellData(3, 3);
		
		String password = ExcelUtils.getCellData(3, 4);
		
		String phoneNumber = ExcelUtils.getCellData(3, 5);
		
		String email = ExcelUtils.getCellData(3, 6); 
		

		//Entering the values obtained from the excel
		agentForm.setFirstName(firstName);
		agentForm.tosleep(1000);
		agentForm.setLastName(lastName);
		agentForm.tosleep(1000);
		agentForm.setUserName(username);
		agentForm.tosleep(1000);
		agentForm.setPassword(password);
		agentForm.tosleep(1000);
		agentForm.setPhoneNumber(phoneNumber);
		agentForm.tosleep(1000);
		agentForm.setEmail(email);
		agentForm.tosleep(1000);

		agentForm.clickSubmit();
		
		//To take Screenshot
		System.out.println("Inside Screenshot Method");
		File src = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(src,new File("C:\\"+"validdetails.png"));
		
		//Displaying the Validated  message
		if(welcomepage.getTitle().equals("Registered Succesfully")){
			ExcelUtils.setCellData("Passed", 3,7);
		}
		else {
			ExcelUtils.setCellData("Failed", 3,7);
		}
		
		//Getting the title 
		titletxt =welcomepage.getTitle();
		System.out.println(titletxt);
	

		//Getting and displaying the Name
		nametxt = welcomepage.getName();
		System.out.println(nametxt);

		//Getting and displaying the Username
		unametxt= welcomepage.getUserName();
		System.out.println(unametxt);

		//Getting and displaying the Phone number
		 phonenumbertxt= welcomepage.getNumber();
		 System.out.println(phonenumbertxt);


		 //Getting and displaying the Email
		 emailtxt= welcomepage.getEmail();
		 System.out.println(emailtxt);

		 //quite the browser
		 agentForm.tosleep(2000);
		 driver.quit();

	}

}
