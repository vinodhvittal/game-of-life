//572849

package com.selenium.tests;

import java.io.File;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.selenium.pages.AgentForm;
import com.selenium.pages.DisplayAgent;
import com.selenium.setup.DriverSetup;
import com.selenium.setup.ExcelUtils;

public class TestAgentForm extends DriverSetup{
    WebDriver driver;
	AgentForm agentForm;
	public static String invalidEmailTxt;
	public static String blankErrtxtForEmail;	
	public static String blankErrtxt;
	
	
	@BeforeClass
	public void setUp() {
		 
		 driver = getDriver();
	}
	
	@Test
	public void testInvalidEmailId() throws Exception {
		
		ExcelUtils.setExcelFile();
		agentForm = new AgentForm(driver);
		
		//Getting values from excel
		String firstName = ExcelUtils.getCellData(1, 1);
		String lastName = ExcelUtils.getCellData(1, 2);
		String username = ExcelUtils.getCellData(1, 3);
		String password = ExcelUtils.getCellData(1, 4);
		String phoneNumber = ExcelUtils.getCellData(1, 5);
		String email = ExcelUtils.getCellData(1, 6);
		
		//Entering the values obtained from the excel
		agentForm.setFirstName(firstName);
		Thread.sleep(1000);
		agentForm.setLastName(lastName);
		Thread.sleep(1000);
		agentForm.setUserName(username);
		Thread.sleep(1000);
		agentForm.setPassword(password);
		Thread.sleep(1000);
		agentForm.setPhoneNumber(phoneNumber);
		Thread.sleep(1000);
		agentForm.setEmail(email);
		Thread.sleep(1000);

		agentForm.clickSubmit();
		Thread.sleep(1000);
		invalidEmailTxt = agentForm.getErrorMessage();
		
		//To take Screenshot
		System.out.println("Inside Screenshot Method");
		File src = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(src,new File("C:\\"+"invalidmail.png"));
		
		//Displaying the Validated error message  
		if(invalidEmailTxt.contains("Enter a valid email id")){
			ExcelUtils.setCellData("Passed", 1,7);	
			System.out.println(invalidEmailTxt +" is displayed when the email id is invalid");
		}else{
			ExcelUtils.setCellData("Failed", 1,7);
		}
		
		//quite the browser
		Thread.sleep(2000);
		driver.quit();
		
	}
	
	
	
	@Test
	public void  testBlankForPasswordAndEmail() throws Exception {
		ExcelUtils.setExcelFile();
		agentForm = new AgentForm(driver);
		//Getting values from excel
		String firstName = ExcelUtils.getCellData(2, 1);
		String lastName = ExcelUtils.getCellData(2, 2);
		String username = ExcelUtils.getCellData(2, 3);
		String password = ExcelUtils.getCellData(2, 4);
		String phoneNumber = ExcelUtils.getCellData(2, 5);
		String email = ExcelUtils.getCellData(2, 6); 
		
		//Entering the values obtained from excel
		agentForm.setFirstName(firstName);
		Thread.sleep(1000);
		agentForm.setLastName(lastName);
		Thread.sleep(1000);
		agentForm.setUserName(username);
		Thread.sleep(1000);
		agentForm.setPassword(password);
		Thread.sleep(1000);
		agentForm.setPhoneNumber(phoneNumber);
		Thread.sleep(1000);
		agentForm.setEmail(email);
		Thread.sleep(1000);

		//Clicking submit button
		agentForm.clickSubmit();
		Thread.sleep(1000);
		
		//getting error text
		blankErrtxt = agentForm.getErrorMessage();
		
		//To take Screenshot
		System.out.println("Inside Screenshot Method");
		File src = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(src,new File("C:\\"+"Blankpasswordandemail.png"));
		
		//Displaying the Validated error message
		if(blankErrtxt.contains("Password cannot be blank") && (blankErrtxt.contains("Email cannot be blank")))
		{
			ExcelUtils.setCellData("Passed", 2,7);
			System.out.println("Text message"+blankErrtxt);
		}
		else{
			ExcelUtils.setCellData("Failed", 2,7);
			System.out.println("Error message"+blankErrtxt);
		}
		
	}
	
	
	

	
	
	
	
}