
public class DocumentBO {

	String findVirus(String word, String virus){
		
		return virus;
		
	}
	
}
