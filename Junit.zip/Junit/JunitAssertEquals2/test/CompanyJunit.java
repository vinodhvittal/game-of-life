import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;


public class CompanyJunit {
	
	private CompanyBO companybo;
	
	@Test
	public void testValidDiscount(){
		 assertEquals("Datex shipping offers discount", companybo.hasDiscount(130, 300));
		 assertEquals("Datex shipping offers discount", companybo.hasDiscount(140, 499));
//		assertEquals("Datex shipping offers discount", companybo.hasDiscount(90, 200));
//		 assertEquals("Datex shipping offers discount", companybo.hasDiscount(200, 499));
//		 assertEquals("Datex shipping offers discount", companybo.hasDiscount(99, 599));
//		 assertEquals("Datex shipping offers discount", companybo.hasDiscount(70, 500));
//		 assertEquals("Datex shipping offers discount", companybo.hasDiscount(100, 300));
//		 assertEquals("Datex shipping offers discount", companybo.hasDiscount(100, 0));
//		 assertEquals("Datex shipping offers discount", companybo.hasDiscount(0, 500));
//		 assertEquals("Datex shipping offers discount", companybo.hasDiscount(0, 0));
//		 assertEquals("Datex shipping offers discount", companybo.hasDiscount(-100, 700));
//		 assertEquals("Datex shipping offers discount", companybo.hasDiscount(100, -700));
//		 assertEquals("Datex shipping offers discount", companybo.hasDiscount(-100, -700));
//		 
//	
//		 assertEquals("Datex shipping offers discount", companybo.hasDiscount(99, 499));
		 
	}

	@Test
	public void testInvalidDiscount(){
		 assertEquals("Datex shipping offers no discount", companybo.hasDiscount(100, 500)); 
		 
		 assertEquals("Datex shipping offers no discount", companybo.hasDiscount(100, 700));
		 assertEquals("Datex shipping offers no discount", companybo.hasDiscount(200, 500)); 
	}
	
	@Before
	public void createObjectForCompanyBO(){
		companybo = new CompanyBO();
	}
}
