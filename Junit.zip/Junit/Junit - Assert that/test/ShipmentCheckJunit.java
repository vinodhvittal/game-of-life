
import java.text.SimpleDateFormat;
import java.util.*;
import org.hamcrest.Matcher;
//import static org.hamcrest.CoreMatchers.*;
import org.junit.*;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.junit.Assert.*;
import static org.hamcrest.Matchers.*;

public class ShipmentCheckJunit {
	static SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
	private ShipmentBO sh;
	@Before
	public void shipmentObjectCreation()
	{
		sh = new ShipmentBO();
	}
	@Test
	public void testFilterShipmentById() throws Exception
	{
		assertEquals(null, sh.filterShipmentById(100, ShipmentDAO.shipmentList));
		assertThat(sh.filterShipmentById(45, ShipmentDAO.shipmentList), hasProperty("name",equalTo("Laptop")));
	}
	
	@Test
	public void testDeleteShipmentDetails() throws Exception
	{
		sh.deleteShipmentDetails(ShipmentDAO.shipmentList,11);
		assertThat(ShipmentDAO.shipmentList, (Matcher)not(hasItems(hasProperty("name",equalTo("Air Cooler")))));
		sh.deleteShipmentDetails(ShipmentDAO.shipmentList,111);
		assertThat(ShipmentDAO.shipmentList, (Matcher)not(hasItems(hasProperty("id",equalTo("111")))));
	}
	
	@Test
	public void testInsertShipmentDetails() throws Exception
	{
		Shipment shmt = new Shipment(10,"Air Cooler10",sdf.parse("01/01/2015"),37);
		ShipmentDAO.shipmentList.add(shmt);
		assertThat(ShipmentDAO.shipmentList,(Matcher) hasItems(hasProperty("name",is(equalTo("Air Cooler10")))));
	}
	
	
}
