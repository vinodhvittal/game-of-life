
public class ShipmentBO {

	public Integer findNearestPort(Integer port1 , Integer port2)
	{
		if(port1 < port2)
			return 1;
		if(port1 > port2)
			return -1;
		
		return 0;
	}
	
}
