import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class ShipmentJUnit {
	double delta = 0.01;
	ShipmentBO shipment;

	@Before
	public void setup() {
		shipment = new ShipmentBO();
	}

	@Test
	public void testCalculateAverage() {
		assertEquals(0, shipment.calculateAverage(0, 0, 0, 0),0);
		assertEquals(42.5, shipment.calculateAverage(1, 20, 3, 50),0);
	}
}
