import java.util.Scanner;
import java.util.Arrays;
import java.util.ArrayList;

public class Main1 {

	int ports_num;
	static int i, j, x, y, a, k;

	public static void main(String args[]) {

		Scanner scan = new Scanner(System.in);
		System.out.println("Enter number of ports :");
		int ports_num = Integer.parseInt(scan.nextLine());
		String[] data1 = new String[ports_num];

		if (ports_num <= 0) {
			System.out.println("Not entered port number accurately");
		} else {
			System.out.println("Enter port details :");

			for (i = 0; i < ports_num; i++) {
				data1[i] = scan.nextLine();
			}
		}
		for (k = 0; k < ports_num; k++) {
			ArrayList aList = new ArrayList(
					Arrays.asList(data1[k].split("\\|")));
			x = 0;
			a = 0;
			j = 2;

//			while (j < aList.size()) {
//				if (aList.get(j) == 1) {
//					a = a + 1;
//				}
//				j = j + 1;
//			}
			System.out.println("One mode of transportation :");
			if (a > 0 && a < 2) {
				System.out.println(aList.get(0) + " " + aList.get(1));
			} else {
				System.out.println("No such transportation available");
			}
			System.out.println("More than one mode of transportation :");
			if (a > 1 && a < 4) {
				System.out.println(aList.get(0) + " " + aList.get(1));
			} else {
				System.out.println("No such transportation available");
			}
		}
		if (scan != null)
			scan.close();
	}
}