import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;

public class RoleBOJUnit {
	@Test
	public void testGetAllRoles() {
		//fill the code
	}
}
