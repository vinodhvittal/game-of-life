import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class RoundOffJUnit {
	RoundOffBO roundOffBO;
	@Before
	public void createObjectForRoundOffBO() {
		roundOffBO = new RoundOffBO();
	}
	@Test
	public void testRoundOffValue() {
		assertEquals(0,roundOffBO.getRoundOffValue(0));
		assertEquals(10,roundOffBO.getRoundOffValue(14));
		assertEquals(20,roundOffBO.getRoundOffValue(15));
	}
}