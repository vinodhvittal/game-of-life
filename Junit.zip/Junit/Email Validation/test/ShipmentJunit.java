import static org.hamcrest.CoreMatchers.*;

import java.text.SimpleDateFormat;
import java.util.*;
import org.junit.*;
import org.hamcrest.Description;
import org.hamcrest.Matcher;
import org.hamcrest.TypeSafeMatcher;
import org.hamcrest.core.IsEqual;
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;

public class ShipmentJunit {

	private ShipmentBO shipmentBO;

	@Before
	public void createObjectForEmailGenerator() {
		shipmentBO = new ShipmentBO();

	}

	@Test
	public void testEmailId() {
		assertThat(shipmentBO.generateEmailId("Maddy Anderson", new Date("10/10/1997")),is("maddyanderson1997@gmail.com"));
		assertThat(shipmentBO.generateEmailId("MARTIN Blake", new Date("10/10/1992")),is("martinblake1992@gmail.com"));
		assertThat(shipmentBO.generateEmailId("MaROOn FiVE", new Date("10/10/2011")),is("maroonfive2011@gmail.com"));
		assertThat(shipmentBO.generateEmailId("mark hellary", new Date("10/10/2000")),is("markhellary2000@gmail.com"));
		
		
		
//		assertThat(shipmentBO.generateEmailId("Maddy Anderson", new Date("10/10/1997")),EmailIdChecker.checkEmail("maddyanderson1997@hotmail.com"));
//		assertThat(shipmentBO.generateEmailId("MARTIN Blake", new Date("10/10/1992")),EmailIdChecker.checkEmail("martinblake1992@hotmail.com"));
//		assertThat(shipmentBO.generateEmailId("MaROOn FiVE", new Date("10/10/2011")),EmailIdChecker.checkEmail("maroonfive2011@hotmail.com"));
//		assertThat(shipmentBO.generateEmailId("mark hellary", new Date("10/10/2000")),EmailIdChecker.checkEmail("markhellary2000@hotmail.com"));
//		
//		assertThat(shipmentBO.generateEmailId("Maddy", new Date("10/10/2000")),EmailIdChecker.checkEmail("maddy2000@hotmail.com"));
//		assertThat(shipmentBO.generateEmailId("MARTIN", new Date("10/10/2000")),EmailIdChecker.checkEmail("martin2000@hotmail.com"));
//		assertThat(shipmentBO.generateEmailId("MaROOn", new Date("10/10/2000")),EmailIdChecker.checkEmail("maroon2000@hotmail.com"));
//		assertThat(shipmentBO.generateEmailId("mark", new Date("10/10/2000")),EmailIdChecker.checkEmail("mark2000@hotmail.com"));
//
//		assertThat(shipmentBO.generateEmailId("Maddy Anderson xx", new Date("10/10/1997")),EmailIdChecker.checkEmail("maddyandersonxx1997@hotmail.com"));
//		assertThat(shipmentBO.generateEmailId("MARTIN Blake XX", new Date("10/10/1992")),EmailIdChecker.checkEmail("martinblakexx1992@hotmail.com"));
//		assertThat(shipmentBO.generateEmailId("MaROOn FiVE xX", new Date("10/10/2011")),EmailIdChecker.checkEmail("maroonfivexx2011@hotmail.com"));
	
	}

}

////class EmailIdChecker {
////	public static Matcher<String> checkEmail(final String emailID) {
////		return new TypeSafeMatcher<String>() {
////		
////			
////
////			@Override
////			public void describeTo(final Description description) {
////				description.appendText("Invalid Email Format");
////			}
////
////			@Override
////			protected boolean matchesSafely(final String value) {
////				return emailID.equals(value);
////			}
////
////		};
////	}
//}