import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;
public class GrammerCheckJUnit {
	GrammerCheckBO grammerCheckBO;
	@Before
	public void createObjectForGrammerCheckBO() {
		grammerCheckBO = new GrammerCheckBO();
	}
	@Test
	public void testGrammmer() {
		assertEquals("an angle",grammerCheckBO.checkGrammer("a angle"));
		assertEquals("an eagle",grammerCheckBO.checkGrammer("a eagle"));
		assertEquals("an ice",grammerCheckBO.checkGrammer("a ice"));
		assertEquals("an orange",grammerCheckBO.checkGrammer("a orange"));
		assertEquals("an umbrella",grammerCheckBO.checkGrammer("a umbrella"));
		
		assertEquals("an Angle",grammerCheckBO.checkGrammer("a Angle"));
		assertEquals("an Eagle",grammerCheckBO.checkGrammer("a Eagle"));
		assertEquals("an Ice",grammerCheckBO.checkGrammer("a Ice"));
		assertEquals("an Orange",grammerCheckBO.checkGrammer("a Orange"));
		assertEquals("an Umbrella",grammerCheckBO.checkGrammer("a Umbrella"));
		
		assertEquals("Hi a Programm",grammerCheckBO.checkGrammer("Hi a Programm"));
		
	}
}