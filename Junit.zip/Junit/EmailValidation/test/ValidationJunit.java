import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class ValidationJunit {
	ValidationBO validationBO;
	
	@Before
	public void init() {
		validationBO = new ValidationBO();
	}
	
	@Test
	public void testValidEmail() {
		assertEquals(true, validationBO.validateEmail("Test@t23est.com"));
		assertEquals(true, validationBO.validateEmail("test.Test@test.com"));
		assertEquals(true, validationBO.validateEmail("test@Test.com"));
		assertEquals(true, validationBO.validateEmail("tes-t@test.Com"));
		assertEquals(true, validationBO.validateEmail("test.1@tes-t.comssfsf.com"));
		assertEquals(true, validationBO.validateEmail("tes-t@test.Com"));
		assertEquals(true, validationBO.validateEmail("test.1@test.comssfsf.com"));
		assertEquals(true, validationBO.validateEmail("test+.1@test.comssfsf.com"));
		
		assertEquals(true, validationBO.validateEmail("test@t23est.com"));
		assertEquals(true, validationBO.validateEmail("test@teSt.com"));
		assertEquals(true, validationBO.validateEmail("test@test.com"));
		assertEquals(true, validationBO.validateEmail("tes-t@test.com"));
		assertEquals(true, validationBO.validateEmail("test.1@test.comssfsf.com"));

	}
	
	@Test
	public void testInvalidEmail() {
		assertEquals(false, validationBO.validateEmail("#test@test.com"));
		assertEquals(false, validationBO.validateEmail("test@test.c"));
		assertEquals(false, validationBO.validateEmail("test..@test.c"));
		assertEquals(false, validationBO.validateEmail("test@test#.c"));
		assertEquals(false, validationBO.validateEmail("test@test.com12"));
		assertEquals(false, validationBO.validateEmail("test@test.fsteczz#.com"));
		assertEquals(false, validationBO.validateEmail("test@test.fsteczz-.com"));
		assertEquals(false, validationBO.validateEmail("@test.fsteczz-.com"));

	}
	
	@After
	public void destroy() {
		validationBO = null;
	}
}
