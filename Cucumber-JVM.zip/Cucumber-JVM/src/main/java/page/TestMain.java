package page;

public class TestMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Testing if I can execute a java class inside maven POM!!!");
	}

}
