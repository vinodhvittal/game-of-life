package stepdefinition1;

import static org.junit.Assert.*;

import org.junit.BeforeClass;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.Scenario;
import cucumber.api.java.*;
import cucumber.api.java.en.*;

public class LoginTest2 {

	static WebDriver driver;
	private Scenario scenario;

	@Before
	public void before(Scenario scenario) {
		this.scenario = scenario;
		String currentDir = System.getProperty("user.dir");
		String driverPath = currentDir + "\\chromedriver.exe";
		System.setProperty("webdriver.chrome.driver", driverPath);
		driver = new ChromeDriver();
	}

	@Given("^I want to be able to login and logout of tangedco website1$")
	public void i_want_to_be_able_to_login_and_logout_of_tangedco_website1() {
		driver.get("https://www.tnebnet.org/awp/login");
		driver.manage().window().maximize();
	}

	@When("^I enter the Username1 \"([^\"]*)\"$")
	public void i_enter_the_Username1(String arg1) {
		// Write code here that turns the phrase above into concrete actions
		driver.findElement(By.id("userName")).sendKeys(arg1);
	}

	@When("^I enter the Password1 \"([^\"]*)\"$")
	public void i_enter_the_Password1(String arg1) {
		// Write code here that turns the phrase above into concrete actions
		driver.findElement(By.id("password")).sendKeys(arg1);
	}

	@When("^I click on login1$")
	public void i_click_on_login1() {
		driver.findElement(By.name("submit")).click();
	}

	@Then("^Home page should be loaded1$")
	public void home_page_should_be_loaded1() {
		WebElement homePageTitle = driver.findElement(By.xpath("//*[@id='header1']/div/table/tbody/tr[3]/td/span"));
		assertEquals("Welcome vinodh should be displayed", "Welcome vinodh vittal,", homePageTitle.getText().trim());
	}

	@When("^I click on logout1$")
	public void i_click_on_logout1() {
		// Write code here that turns the phrase above into concrete actions
		driver.findElement(By.xpath("//*[@id='header1']/div/table/tbody/tr[1]/td/a[4]/span")).click();
	}

	@Then("^I should see you have been logged out1$")
	public void i_should_see_you_have_been_logged_out1() {
		// Write code here that turns the phrase above into concrete actions
		WebElement loggedOut = driver.findElement(By.xpath("//*[@id='j_idt28_content']/p[1]"));
		assertEquals("Welcome vinodh should be displayed", "You have been logged out", loggedOut.getText().trim());

	}

	@After
	public void tearDown(Scenario scenario) {
		if (scenario.isFailed()) {
			scenario.embed(((TakesScreenshot) driver).getScreenshotAs(OutputType.BYTES), "image/png");
		}
		driver.quit();
	}

}
