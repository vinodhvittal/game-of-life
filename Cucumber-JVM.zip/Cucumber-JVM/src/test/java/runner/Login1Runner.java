package runner;

import java.io.File;

import org.junit.BeforeClass;
import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;
import listener.ExtentCucumberListener;

@RunWith(Cucumber.class)
@CucumberOptions(monochrome = true, features = { "src/test/java/feature/Login.feature" }, format = {
		"json:target/cucumber-report/report1.json" }, glue = { "stepdefinition" })
public class Login1Runner {

	@BeforeClass
	public static void setup() {
		//ExtentCucumberListener listener = new ExtentCucumberListener(new File("Report\\runner1.html"));
		//listener.loadConfig(new File("reportConfig.xml"));
	}
}