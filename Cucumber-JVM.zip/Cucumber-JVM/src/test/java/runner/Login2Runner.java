package runner;

import java.io.File;

import org.junit.BeforeClass;
import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;
import listener.ExtentCucumberListener;

@RunWith(Cucumber.class)
@CucumberOptions(monochrome = true, features = { "src/test/java/feature/Login1.feature" }, format = {
		"json:target/cucumber-report/report2.json" }, glue = { "stepdefinition1" })
public class Login2Runner {

	@BeforeClass
	public static void setup() {
		// ExtentCucumberListener listener = new ExtentCucumberListener(new
		// File("Report\\runner2.html"));
		// listener.loadConfig(new File("reportConfig.xml"));
	}
}