import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class UserDAO {

    public List<User> getAllUsers() throws Exception {
    	List<User> userList = new ArrayList<User>();
		Connection con = DbConnection.getConnection();
		String query = "select *from user";
		Statement statement = con.createStatement();
		ResultSet resultSet = statement.executeQuery(query);
		while (resultSet.next()) {
			userList.add(new User(resultSet.getInt(1), resultSet.getString(2),
					resultSet.getString(3), resultSet.getString(4)));
		}
		return userList;
	}
}
