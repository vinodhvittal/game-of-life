import java.sql.SQLException;
import java.util.List;

public class ClerkBO extends UserBO{

	@Override
	List<Invoice> listInvoice() throws InsufficientPrivilegeException {
		// TODO Auto-generated method stub
		throw new InsufficientPrivilegeException("Permission Denied");
	}

	@Override
	Integer createInvoice(Invoice invoice) throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		InvoiceDAO invoiceDAO = new InvoiceDAO();
		return invoiceDAO.invoiceCreation(invoice);
	}

}
