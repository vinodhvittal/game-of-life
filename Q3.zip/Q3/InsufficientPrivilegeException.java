
public class InsufficientPrivilegeException extends Exception {
    public InsufficientPrivilegeException(String s){
        super(s);
    }

}
