import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class InvoiceDAO {
	List<Invoice> invoices = new ArrayList<Invoice>();
	Integer invoiceCreation(Invoice invoice) throws ClassNotFoundException, SQLException{
		Connection conn = DbConnection.getConnection();
		String sql = "INSERT into invoice(invoice_number,status,amount,created_date,user_id) VALUES(?,?,?,?,?)";
		Statement stmt1 = conn.createStatement();
		ResultSet rs1 = stmt1.executeQuery("select * from user where username='"+invoice.getCreatedBy().getUserName()+"'");
		//System.out.println("select * from user where username='"+invoice.getCreatedBy().getUserName()+"'");
		rs1.next();
		int userid = rs1.getInt("id");
		PreparedStatement prest = conn.prepareStatement(sql);
	    prest.setString(1, invoice.getInvoiceNumber());
	    prest.setString(2, "Pending");
	    prest.setInt(3, invoice.getAmount());
	    prest.setDate(4, new java.sql.Date(invoice.getCreatedDate().getTime()));
	    prest.setInt(5, userid);
	    int row = prest.executeUpdate();
	    //System.out.println(row + " row(s) affected)");
		Statement stmt = conn.createStatement();
		ResultSet rs = stmt.executeQuery("select id from invoice where invoice_number='"+invoice.getInvoiceNumber()+"'");
		rs.next();
		int roleid = rs.getInt("id"); 
		return roleid;
		
	}
	List<Invoice> getAllInvoiceList() throws SQLException, ClassNotFoundException{
		Connection conn = DbConnection.getConnection();
		Statement stmt1=conn.createStatement();
		ResultSet rs1 = stmt1.executeQuery("select *from invoice");
		Statement stmt2=conn.createStatement();
		while(rs1.next()){
			ResultSet rs2 = stmt2.executeQuery("select user.id,user.username,user.password,user.role from user,invoice where user.id="+rs1.getInt("user_id"));
			rs2.next();
			User user = new User(rs2.getInt("id"), rs2.getString("username"), rs2.getString("password"), rs2.getString("role"));
			invoices.add(new Invoice(rs1.getInt("id"),rs1.getString("invoice_number"), rs1.getString("status"),rs1.getInt("amount"), rs1.getDate("created_date"), user));
		}
		return invoices;	
	}
	
}
