import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public abstract class UserBO {
	
	static List<User> users = new ArrayList<User>();
	abstract List<Invoice> listInvoice() throws InsufficientPrivilegeException, ClassNotFoundException, SQLException;
	abstract Integer createInvoice(Invoice invoice) throws InsufficientPrivilegeException, ClassNotFoundException, SQLException;
	
	public static User validateUser(String username,String password) throws Exception{
		UserDAO userDAO = new UserDAO();		
		users = userDAO.getAllUsers();
		Iterator<User> itr = users.iterator();
		while(itr.hasNext()){
			User user = itr.next();
			if(user.getUserName().equals(username)&&user.getPassword().equals(password)){
				return user;
			}
		}
			
		 return null;
	}
}
