package com.item.tests;

import static org.testng.Assert.assertEquals;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.item.pages.ItemListPage;
import com.item.pages.SearchPage;
import com.item.setup.DriverSetup;
import com.item.setup.ExcelUtils;


public class SearchItemTest extends DriverSetup{
	SearchPage searchPage;
	ItemListPage itemListPage;
	public static String blankErrTxt;
	public static String emptymessage;
	public static String itemCodeTxt;
	public static String itemNameTxt;
	public static String itemPriceTxt;
	public static String itemDescriptionTxt;
	
	WebDriver driver;
	
	@BeforeMethod
	public void setUp() {
		
		driver = getDriver();
}
	
	
	@Test
	public void testBlankForItemCategory() throws Exception {

		ExcelUtils.setExcelFile();
		searchPage=new SearchPage(driver);
		System.out.println("Inside method");
		String category = ExcelUtils.getCellData(1, 1);
		System.out.println(category);
		String startPrice = ExcelUtils.getCellData(1, 2);
		String endPrice = ExcelUtils.getCellData(1, 3);
		
		searchPage.setCategory(category);
		Thread.sleep(1000);
		searchPage.setStartPrice(startPrice);
		Thread.sleep(1000);
		searchPage.setEndPrice(endPrice);
		Thread.sleep(1000);
		searchPage.clickSearch();
		Thread.sleep(1000);
		blankErrTxt = searchPage.getErrorMessage();
		Reporter.log(blankErrTxt);
}
	
		
	@Test
	public void testSearchForEmptyList() throws Exception {
		ExcelUtils.setExcelFile();
		searchPage=new SearchPage(driver);
		itemListPage=new ItemListPage(driver);
		String category = ExcelUtils.getCellData(2, 1);
		String startPrice = ExcelUtils.getCellData(2, 2);
		String endPrice = ExcelUtils.getCellData(2, 3);
		searchPage.setCategory(category);
		Thread.sleep(1000);
		searchPage.setStartPrice(startPrice);
		Thread.sleep(1000);
		searchPage.setEndPrice(endPrice);
		Thread.sleep(1000);
		searchPage.clickSearch();
		Thread.sleep(1000);
		emptymessage=itemListPage.getEmptyMessage();
		Reporter.log(emptymessage);
		
	}
	
	
	@Test 
	public void testSearchForResults() throws Exception {
		
		ExcelUtils.setExcelFile();
		searchPage=new SearchPage(driver);
		itemListPage=new ItemListPage(driver);
		
		String category = ExcelUtils.getCellData(3, 1);
		String startPrice = ExcelUtils.getCellData(3, 2);
		String endPrice = ExcelUtils.getCellData(3, 3);
		searchPage.setCategory(category);
		Thread.sleep(1000);
		searchPage.setStartPrice(startPrice);
		Thread.sleep(1000);
		searchPage.setEndPrice(endPrice);
		Thread.sleep(1000);
		searchPage.clickSearch();
		Thread.sleep(1000);
		itemCodeTxt= itemListPage.getItemCode();
		itemNameTxt= itemListPage.getItemName();		
		itemPriceTxt=itemListPage.getItemPrice();
		itemDescriptionTxt=itemListPage.getItemDescription();
		Reporter.log(itemCodeTxt);
		Reporter.log(itemNameTxt);
		Reporter.log(itemPriceTxt);
		Reporter.log(itemDescriptionTxt);
	}
	
	
	@AfterMethod
	public void driverQuit(){
		driver.quit();
	}
	
	
}
