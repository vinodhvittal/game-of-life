package com.item.setup;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;


public class DriverSetup {
	public static String baseUrl = "http://apps.qa2qe.cognizant.e-box.co.in/Item_search_4500/";
	
	public WebDriver getDriver() {
		System.setProperty("webdriver.gecko.driver", "C:\\Users\\572327\\Documents\\driver\\geckodriver.exe");
		WebDriver driver = new FirefoxDriver();
		driver.navigate().to(DriverSetup.baseUrl);
		return driver;
	}

}
