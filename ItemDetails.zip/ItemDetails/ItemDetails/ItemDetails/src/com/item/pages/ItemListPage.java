package com.item.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class ItemListPage {
	// fill the code
	
	public WebDriver driver;
	public ItemListPage (WebDriver driver)
	{
		this.driver = driver;
		PageFactory.initElements(this.driver, this);
	}
	
	@FindBy (how=How.XPATH,xpath="//table/tbody/tr[2]/td[2]")
	WebElement code;
	
	@FindBy (how=How.XPATH,xpath="//table/tbody/tr[2]/td[3]")
	WebElement itemName;
	
	@FindBy (how=How.XPATH,xpath="//table/tbody/tr[2]/td[4]")
	WebElement Price;
	
	@FindBy (how=How.NAME,xpath="//table/tbody/tr[2]/td[5]")
	WebElement Desc;
	
	@FindBy (how=How.XPATH,xpath="//html/body/center/h4")
	WebElement EmptyMsg;
	
	public String getItemCode(){
		String txt=code.getText();
		return txt;
	}
	
	public String getItemName(){
		String txt=itemName.getText();
		return txt;
	}
	
	public String getItemPrice(){
		String txt=Price.getText();
		return txt;
	}
	public String getItemDescription(){
		String txt=Desc.getText();
		return txt;
	}
	
	public String getEmptyMessage(){
		String txt=EmptyMsg.getText();
		return txt;
	}
}
