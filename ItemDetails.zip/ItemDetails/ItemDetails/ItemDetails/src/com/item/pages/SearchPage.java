package com.item.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class SearchPage {
	// fill the code
	public WebDriver driver;
	public SearchPage (WebDriver driver)
	{
		this.driver = driver;
		PageFactory.initElements(this.driver, this);
	}
	
	@FindBy (how=How.NAME,name="category")
	WebElement category;
	
	@FindBy (how=How.NAME,name="startPrice")
	WebElement startPrice;
	
	@FindBy (how=How.NAME,name="endPrice")
	WebElement endPrice;
	
	@FindBy (how=How.NAME,name="search")
	WebElement search;
	
	@FindBy (how=How.XPATH,xpath="//h3")
	WebElement ErrorMsg;
	
	public void setCategory(String itemCat){
		category.sendKeys(itemCat);
	}
	
	public void setStartPrice(String SPrice){
		startPrice.sendKeys(SPrice);
	}
	
	public void setEndPrice(String Eprice){
		endPrice.sendKeys(Eprice);
	}
	
	public void clickSearch(){
		search.click();
	}
	
	public String getErrorMessage()   
	{
		String txt = ErrorMsg.getText();
		return txt;
				
	}
	
}
