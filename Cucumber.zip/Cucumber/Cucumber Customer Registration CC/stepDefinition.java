package com.cucumber.stepdefinition;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import static org.testng.Assert.assertEquals;

public class stepDefinition {
	public WebDriver driver;
	String text;
	String click, customername, age, address, phonenumber, email, expname;
	String Expected = "Registered Succesfully";
	
	@Given("^User launches the Registration URL$")
	public void setUp() {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\309406\\Desktop\\Ebox\\Fitnesse CC\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.get("http://apps.qa2qe.cognizant.e-box.co.in/CustomerRegistration/Index");
        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
	    
	}

	@When("^User enters name as \"([^\"]*)\", Age as \"([^\"]*)\", Address as \"([^\"]*)\", Phone Number as \"([^\"]*)\", Email as \"([^\"]*)\", clicks \"([^\"]*)\" button$")
	public void testCustomerRegistration(String arg1, String arg2, String arg3, String arg4, String arg5, String arg6) throws Throwable {
		driver.findElement(By.xpath("//*[@id='agent-form']/table/tbody/tr[1]/td[2]/input")).sendKeys(arg1);
		driver.findElement(By.xpath("//*[@id='agent-form']/table/tbody/tr[2]/td[2]/input")).sendKeys(arg2);
		driver.findElement(By.xpath("//*[@id='agent-form']/table/tbody/tr[3]/td[2]/input")).sendKeys(arg3);
		driver.findElement(By.xpath("//*[@id='agent-form']/table/tbody/tr[4]/td[2]/input")).sendKeys(arg4);
		driver.findElement(By.xpath("//*[@id='agent-form']/table/tbody/tr[5]/td[2]/input")).sendKeys(arg5);
		driver.findElement(By.xpath("//*[@id='"+arg6+"']")).click();
	   click=arg6;
	   customername=arg1;
	   age=arg2;
	   expname=customername+" "+age;
	   address=arg3;
	   phonenumber=arg4;
	   email=arg5;
	}

	@Then("^user is registered with user details displayed$")
	public void validateResult() throws Throwable {
		if(click.equals("submit")){
	 text=driver.findElement(By.xpath("/html/body/h2")).getText();
	 assertEquals(text,Expected);
	 String a=driver.findElement(By.xpath("/html/body/table/tbody/tr[1]/td[2]")).getText();
	 String actage=driver.findElement(By.xpath("/html/body/table/tbody/tr[2]/td[2]")).getText();
	
	 String actaddress=driver.findElement(By.xpath("/html/body/table/tbody/tr[3]/td[2]")).getText();
	 String actph=driver.findElement(By.xpath("/html/body/table/tbody/tr[4]/td[2]")).getText();
	 String actemail=driver.findElement(By.xpath("/html/body/table/tbody/tr[5]/td[2]")).getText();
	 assertEquals(expname,a);
	 assertEquals(age,actage);
	 assertEquals(address,actaddress);
	 assertEquals(phonenumber,actph);
	 assertEquals(email,actemail);
		}
	
	}

}
