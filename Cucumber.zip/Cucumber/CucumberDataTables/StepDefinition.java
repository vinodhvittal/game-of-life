package com.cucumber.stepdefinition;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import static org.testng.Assert.assertEquals; 

public class StepDefinition {
	public WebDriver driver;
	private String actualname;
	private String Expectedresult;
	
	@Given("^User launches the Shipping Details URL$")
	public void setUp() {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\309406\\Desktop\\Ebox\\Fitnesse CC\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.get("http://apps.qa2qe.cognizant.e-box.co.in/Handling_Reg_Expression");
        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);

	}

	@When("^user enters \"([^\"]*)\", clicks on Search button$")
	public void testUserDetails(String arg1)  {
		driver.findElement(By.xpath("//input[@id='userId']")).sendKeys(arg1);
		driver.findElement(By.xpath("//*[@id='track']")).click();
	    
	}

	@Then("^\"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\" are displayed$")
	public void validateResult(String Name, String ShipmentId, String PhoneNumber, String Email) throws Throwable {
	    actualname=driver.findElement(By.id("result")).getText();
	    Expectedresult="Name : " +Name+ "\n" + "Shipment Id : " +ShipmentId+ "\n" + "Phone Number : " +PhoneNumber+ "\n" +
	    "E-mail: " +Email;
	    assertEquals(actualname,Expectedresult);
	    
	}

	


}
