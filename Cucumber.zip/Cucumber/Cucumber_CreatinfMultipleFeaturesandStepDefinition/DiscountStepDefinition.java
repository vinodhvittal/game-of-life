package com.cucumber.stepdefinition;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import static org.junit.Assert.*;
public class DiscountStepDefinition {
	public WebDriver driver;
	private String text;
	
	@Given("^User launches the DATAX Shipping Company URL$")
	public void setUp() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\309406\\Desktop\\Ebox\\Fitnesse CC\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.get("http://apps.qa2qe.cognizant.e-box.co.in/CompanyOffersDiscount/");
        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
	   // throw new PendingException();
	}

	@When("^user enters weight as \"([^\"]*)\" , distance as \"([^\"]*)\" , clicks Submit$")
	public void testDiscount(String arg1, String arg2) throws Throwable {
		driver.findElement(By.xpath("//input[@id='weight']")).sendKeys(arg1);
		driver.findElement(By.xpath("//input[@id='distance']")).sendKeys(arg2);
		driver.findElement(By.xpath("//*[@id='submit']")).click();
	}

	@Then("^\"([^\"]*)\" is displayed$")
	public void validateResult(String discount) throws Throwable {
		Thread.sleep(1000);
		text=driver.findElement(By.xpath("//*[@id='result']")).getText();
		Thread.sleep(1000);
		assertEquals("Output matched", discount, text);
	}

}
