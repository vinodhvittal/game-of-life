package com.cucumber.stepdefinition;

import static org.junit.Assert.assertEquals;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import static org.testng.Assert.assertEquals; 

public class NodiscountStepDefinition {
	public WebDriver driver;
	private String text2;
	String nodisc; 
	
	@Given("^User launches the application URL for no discount$")
	public void setUp() throws Throwable {
		
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\309406\\Desktop\\Ebox\\Fitnesse CC\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.get("http://apps.qa2qe.cognizant.e-box.co.in/CompanyOffersDiscount/");
        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
		
	   
	}

	@When("^the user enters weight as \"([^\"]*)\" , distance as \"([^\"]*)\" , clicks Submit$")
	public void testNodiscount(String arg1, String arg2) throws Throwable {
		
		driver.findElement(By.xpath("//input[@id='weight']")).sendKeys(arg1);
		driver.findElement(By.xpath("//input[@id='distance']")).sendKeys(arg2);
		driver.findElement(By.xpath("//*[@id='submit']")).click();
	    
	}

	@Then("^message for no discount \"([^\"]*)\" is displayed$")
	public void validateResult(String nodiscount) throws Throwable {
		nodisc = nodiscount;
		Thread.sleep(1000);
		text2=driver.findElement(By.xpath("//*[@id='result']")).getText();
		Thread.sleep(1000);
		assertEquals(nodisc, text2);
	 
	}

}
