

public class Main {

	//Please "DO NOT CHANGE" the below two flags
	public static boolean crocodileRescued;
	public static boolean kombaiRescued;
	
	//Declare main method -- FILL YOUR CODE HERE
	public static void main(String[] args)
	{
	// <Interface Name that needs to be implemented in job class> <objectName> = new job class();
		Runnable obj1 = new RescueBoatTrips();
		
	// Create instances of thread
		Thread t1 = new Thread(obj1);
		Thread t2 = new Thread(obj1);
	// FILL YOUR CODE HERE..
		
	
		t1.setName("Crocodile Rescue Mission");		
		t1.setPriority(Thread.MIN_PRIORITY);
		t2.setName("Kombai Dog");
		t2.setPriority(Thread.MAX_PRIORITY);
												
		t2.start();
		t1.start();	
		
	
	 
		//start your most commonly used exception handling mechanism that you might have seen multiple times in LCs and CCs
		try
		{
			Thread.sleep(200);	//Please do not chage the thread sleep time
			crocodileRescued = t1.isAlive()?false:true;
			kombaiRescued = t2.isAlive()?false:true;
			System.out.println("Mark's mission completed successfully..."+crocodileRescued);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	} //main ends here

}
