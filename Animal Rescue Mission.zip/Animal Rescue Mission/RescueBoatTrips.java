


public class RescueBoatTrips implements Runnable	// <==  complete the job class declaration which is incomplete now
 {	
	public static String rescuedAnimal;
	public static int priority;
	
	@Override
	public void run() {
		
		//assign priority to the thread based on the animal -- FILL YOUR CODE HERE
		priority = Thread.currentThread().getPriority();
		
		switch(priority){
			//if priority is HIGH, call the <shipOnlyOne> method to save the Kombai dog. -- FILL YOUR CODE HERE
		case Thread.MAX_PRIORITY: rescuedAnimal = "Kombai Dog"; 
								  System.out.println("[Prioritized Kombai Dog Rescue comes first...]");
								  shipOnlyOne(rescuedAnimal);
								  Main.kombaiRescued = true;
		break;
		case Thread.MIN_PRIORITY: rescuedAnimal = "Crocodile"; 
								  System.out.println("[Crocodile Rescue comes next]");
								  shipOnlyOther(rescuedAnimal);
								  Main.crocodileRescued = true;
								  
		break;
				
		} //case-structure ends
		
		Main.kombaiRescued = true;
		Main.crocodileRescued = true;
	} //method_name_expected_to_be_overridden ends
	
	//Use the appropriate Keyword to lock the method.
	 synchronized void shipOnlyOne(String animalInTheBoat){
	  
	  //print statement showing proof of (1) currently running thread and (2) the animal being rescued
		 System.out.println(animalInTheBoat + " Rescue mission is underway...");
		 System.out.println(Thread.currentThread().getName()+ " with broken leg successfully taken to safety!");
	  //FILL YOUR CODE HERE	 	 		 
		// Main.kombaiRescued = true;			
	/*	 if(animalInTheBoat=="Crocodile")
			 Main.crocodileRescued = true;*/
	} 
	 synchronized void shipOnlyOther(String animalInTheBoat){
		  
		  //print statement showing proof of (1) currently running thread and (2) the animal being rescued
			 System.out.println(animalInTheBoat + " Rescue mission is underway...");
			 System.out.println(Thread.currentThread().getName()+ " with broken leg successfully taken to safety!");
		 /* //FILL YOUR CODE HERE	 	 		 
			 if(animalInTheBoat=="Kombai Dog") 
				 Main.kombaiRescued = true;	*/		
		} 

 } 
